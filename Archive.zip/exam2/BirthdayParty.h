#ifndef _BIRTHDAY_PARTY_H_
#define _BIRTHDAY_PARTY_H_

#include <iostream>
#include <list>
#include <vector>
#include <string>
#include "Party.h"
#include "BirthdayPartyTicket.h"

//Create BirthdayParty and BirthdayPartyTicket to host birthday parties!
// FIXME 3: Update PartyFactory::factory() to allow it to be the ONLY method for creating a BirthdayParty
/**
* BirthdayParty is derived from Party
*/
class BirthdayParty : public Party
{
private:
    std::list<std::string> room; // Data structure for containing the party goers in this dinner party
    
    /**
     * Constructor for creating a BirthdayParty
     */
    BirthdayParty() {}
    
    friend class PartyFactory;
    
public:
    
    /**
     * Add a person to the party
     * @param name the name of the party goer
     */
    PartyTicket * add(std::string name) {
        room.push_front(name);
        std::list<std::string>::iterator me;
        me->front();
        BirthdayPartyTicket *party = new BirthdayPartyTicket(this, me);
        return party;
    }
    
    
    void list() {
        //iterate through all the persons here.
        for(int i = 0; i < room.size(); i++)
        {
            std::cout << room.front();
        }
    }
    
    /**
     * Remove the person identified by the iterator from the party
     */
    void remove(std::list<std::string>::iterator it) {
        //someone's getting out of hand. Let's ask them to leave.
        room.erase(it);
    }
};

#endif
